<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\BladeDirectivesServiceProvider::class,
    App\Providers\GlobalVariablesServiceProvider::class,
];
