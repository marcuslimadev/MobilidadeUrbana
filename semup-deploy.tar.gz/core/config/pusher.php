<?php
$pusherAppId       = "2012578";
$pusherAppKey      ="652e19bbc55fa342cce6";
$pusherAppSecret   ="47fc3e77261924cd9eaa";
$pusherAppCluster  ="ap2";
?>