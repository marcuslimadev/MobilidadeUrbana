<tbody>
    {{ $slot }}
</tbody>
