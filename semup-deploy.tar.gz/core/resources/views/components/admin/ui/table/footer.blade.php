<div class="table-footer">
    {{ $slot }}
</div>
