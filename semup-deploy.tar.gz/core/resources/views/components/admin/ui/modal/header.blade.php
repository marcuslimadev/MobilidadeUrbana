<div {{ $attributes->merge(['class' => 'modal-header']) }}>
    {{ $slot }}
</div>
