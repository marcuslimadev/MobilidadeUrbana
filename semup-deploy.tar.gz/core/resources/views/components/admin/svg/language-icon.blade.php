<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
    <g clip-path="url(#clip0_453_626)">
        <path d="M4.1665 6.66699L9.1665 11.667" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
        <path d="M3.3335 11.667L8.3335 6.66699L10.0002 4.16699" stroke="hsl(var(--dark))" stroke-width="1.5"
            stroke-linecap="round" stroke-linejoin="round" />
        <path d="M1.6665 4.16699H11.6665" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
        <path d="M5.8335 1.66699H6.66683" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
        <path d="M18.3333 18.3336L14.1667 10.0002L10 18.3336" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
        <path d="M11.6665 15.0002H16.6665" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
    </g>
    <defs>
        <clipPath id="clip0_453_626">
            <rect width="20" height="20" fill="hsl(var(--white))" transform="translate(0 0.000244141)" />
        </clipPath>
    </defs>
</svg>
