<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
  <g clip-path="url(#clip0_454_853)">
    <path d="M9.99984 18.3337C14.6022 18.3337 18.3332 14.6027 18.3332 10.0003C18.3332 5.39795 14.6022 1.66699 9.99984 1.66699C5.39746 1.66699 1.6665 5.39795 1.6665 10.0003C1.6665 14.6027 5.39746 18.3337 9.99984 18.3337Z" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M9.99984 1.66699C7.86003 3.91379 6.6665 6.89761 6.6665 10.0003C6.6665 13.103 7.86003 16.0869 9.99984 18.3337C12.1396 16.0869 13.3332 13.103 13.3332 10.0003C13.3332 6.89761 12.1396 3.91379 9.99984 1.66699Z" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M1.6665 10.0002H18.3332" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_454_853">
      <rect width="20" height="20" fill="hsl(var(--white))" transform="translate(0 0.000244141)"/>
    </clipPath>
  </defs>
</svg>