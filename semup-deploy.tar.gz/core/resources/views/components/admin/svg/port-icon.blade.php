<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
  <path d="M12.4998 16.6671L14.9998 14.1671H16.6665C17.1085 14.1671 17.5325 13.9915 17.845 13.6789C18.1576 13.3664 18.3332 12.9424 18.3332 12.5004V5.00041C18.3332 4.55838 18.1576 4.13446 17.845 3.8219C17.5325 3.50933 17.1085 3.33374 16.6665 3.33374H3.33317C2.89114 3.33374 2.46722 3.50933 2.15466 3.8219C1.8421 4.13446 1.6665 4.55838 1.6665 5.00041V12.5004C1.6665 12.9424 1.8421 13.3664 2.15466 13.6789C2.46722 13.9915 2.89114 14.1671 3.33317 14.1671H4.99984L7.49984 16.6671H12.4998Z" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M5 6.66724V7.50057" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M8.3335 6.66724V7.50057" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M11.6665 6.66724V7.50057" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M15 6.66724V7.50057" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>