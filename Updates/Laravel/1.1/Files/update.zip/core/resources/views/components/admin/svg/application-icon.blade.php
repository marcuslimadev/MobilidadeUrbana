<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
    <g clip-path="url(#clip0_453_600)">
        <path
            d="M16.6665 3.33337H3.33317C2.4127 3.33337 1.6665 4.07957 1.6665 5.00004V15C1.6665 15.9205 2.4127 16.6667 3.33317 16.6667H16.6665C17.587 16.6667 18.3332 15.9205 18.3332 15V5.00004C18.3332 4.07957 17.587 3.33337 16.6665 3.33337Z"
            stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M8.3335 3.33337V6.66671" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
        <path d="M1.6665 6.66663H18.3332" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
    </g>
    <defs>
        <clipPath id="clip0_453_600">
            <rect width="20" height="20" fill="hsl(var(--white))" />
        </clipPath>
    </defs>
</svg>
