<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Traits\RoleOperation;

class RoleController extends Controller
{
    use RoleOperation;
}
