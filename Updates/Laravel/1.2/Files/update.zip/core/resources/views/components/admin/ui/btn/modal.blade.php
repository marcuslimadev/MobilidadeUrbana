<div class="d-flex flex-wrap gap-2 justify-content-end">
    <button type="button" class="btn btn--secondary btn-large" data-bs-dismiss="modal">
        <i class="fa-solid fa-xmark"></i>  @lang('Close')
    </button>
    <button type="submit" class="btn btn--primary btn-large">
        <i class="fa-regular fa-paper-plane"></i> @lang('Submit')
    </button>
</div>
