<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path d="M15 13.3334L18.3333 10.0001L15 6.66675" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
        stroke-linejoin="round" />
    <path d="M4.99984 6.66675L1.6665 10.0001L4.99984 13.3334" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
        stroke-linejoin="round" />
    <path d="M12.0832 3.3335L7.9165 16.6668" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round"
        stroke-linejoin="round" />
</svg>
