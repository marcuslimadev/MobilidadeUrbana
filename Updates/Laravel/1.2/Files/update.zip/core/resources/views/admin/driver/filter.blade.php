<form  id="filter-form">
    <x-admin.other.filter_date label="Join Date" />
    <x-admin.other.order_by />
    <x-admin.other.per_page_record />
    <x-admin.other.filter_dropdown_btn />
</form>
