<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
  <g clip-path="url(#clip0_454_843)">
    <path d="M16.6663 8.33366C16.6663 12.4945 12.0505 16.8278 10.5005 18.1662C10.3561 18.2747 10.1803 18.3335 9.99967 18.3335C9.81901 18.3335 9.64324 18.2747 9.49884 18.1662C7.94884 16.8278 3.33301 12.4945 3.33301 8.33366C3.33301 6.56555 4.03539 4.86986 5.28563 3.61961C6.53587 2.36937 8.23156 1.66699 9.99967 1.66699C11.7678 1.66699 13.4635 2.36937 14.7137 3.61961C15.964 4.86986 16.6663 6.56555 16.6663 8.33366Z" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M10 10.8335C11.3807 10.8335 12.5 9.71421 12.5 8.3335C12.5 6.95278 11.3807 5.8335 10 5.8335C8.61929 5.8335 7.5 6.95278 7.5 8.3335C7.5 9.71421 8.61929 10.8335 10 10.8335Z" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_454_843">
      <rect width="20" height="20" fill="hsl(var(--white))" transform="translate(0 0.000244141)"/>
    </clipPath>
  </defs>
</svg>