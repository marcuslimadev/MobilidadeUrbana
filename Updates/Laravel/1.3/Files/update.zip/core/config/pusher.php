<?php
$pusherAppId       = "------------";
$pusherAppKey      ="------------";
$pusherAppSecret   ="------------";
$pusherAppCluster  ="------------";
?>