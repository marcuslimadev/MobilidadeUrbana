<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
  <g clip-path="url(#clip0_456_987)">
    <path d="M3.3335 8.3335V13.3335" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M16.6665 8.3335V13.3335" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M5.8335 7.50016H14.1668M5.8335 7.50016V14.1668C5.8335 14.3878 5.92129 14.5998 6.07757 14.7561C6.23385 14.9124 6.44582 15.0002 6.66683 15.0002H13.3335C13.5545 15.0002 13.7665 14.9124 13.9228 14.7561C14.079 14.5998 14.1668 14.3878 14.1668 14.1668V7.50016M5.8335 7.50016C5.8335 6.39509 6.27248 5.33529 7.05388 4.55388C7.83529 3.77248 8.89509 3.3335 10.0002 3.3335C11.1052 3.3335 12.165 3.77248 12.9464 4.55388C13.7278 5.33529 14.1668 6.39509 14.1668 7.50016" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M6.6665 2.50024L7.49984 4.16691" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M13.3333 2.50024L12.5 4.16691" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M7.5 15.0002V17.5002" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M12.5 15.0002V17.5002" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_456_987">
      <rect width="20" height="20" fill="hsl(var(--white))" transform="translate(0 0.000244141)"/>
    </clipPath>
  </defs>
</svg>