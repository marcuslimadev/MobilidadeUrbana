<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
  <g clip-path="url(#clip0_454_828)">
    <path d="M10 6.66675C14.1421 6.66675 17.5 5.54746 17.5 4.16675C17.5 2.78604 14.1421 1.66675 10 1.66675C5.85786 1.66675 2.5 2.78604 2.5 4.16675C2.5 5.54746 5.85786 6.66675 10 6.66675Z" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M2.5 4.16675V15.8334C2.5 16.4965 3.29018 17.1323 4.6967 17.6012C6.10322 18.07 8.01088 18.3334 10 18.3334C11.9891 18.3334 13.8968 18.07 15.3033 17.6012C16.7098 17.1323 17.5 16.4965 17.5 15.8334V4.16675" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M2.5 10.0001C2.5 10.6632 3.29018 11.299 4.6967 11.7679C6.10322 12.2367 8.01088 12.5001 10 12.5001C11.9891 12.5001 13.8968 12.2367 15.3033 11.7679C16.7098 11.299 17.5 10.6632 17.5 10.0001" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_454_828">
      <rect width="20" height="20" fill="hsl(var(--white))"/>
    </clipPath>
  </defs>
</svg>