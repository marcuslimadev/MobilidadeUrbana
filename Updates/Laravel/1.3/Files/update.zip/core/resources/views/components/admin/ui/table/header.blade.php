<thead>{{ $slot }}</thead>
