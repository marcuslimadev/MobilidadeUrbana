<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
  <g clip-path="url(#clip0_454_865)">
    <path d="M10 12.5002C11.3807 12.5002 12.5 11.381 12.5 10.0002C12.5 8.61953 11.3807 7.50024 10 7.50024C8.61929 7.50024 7.5 8.61953 7.5 10.0002C7.5 11.381 8.61929 12.5002 10 12.5002Z" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M3.74984 8.33366H3.33317C2.89114 8.33366 2.46722 8.15806 2.15466 7.8455C1.8421 7.53294 1.6665 7.10902 1.6665 6.66699V3.33366C1.6665 2.89163 1.8421 2.46771 2.15466 2.15515C2.46722 1.84259 2.89114 1.66699 3.33317 1.66699H16.6665C17.1085 1.66699 17.5325 1.84259 17.845 2.15515C18.1576 2.46771 18.3332 2.89163 18.3332 3.33366V6.66699C18.3332 7.10902 18.1576 7.53294 17.845 7.8455C17.5325 8.15806 17.1085 8.33366 16.6665 8.33366H16.2498" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M3.74984 11.667H3.33317C2.89114 11.667 2.46722 11.8426 2.15466 12.1551C1.8421 12.4677 1.6665 12.8916 1.6665 13.3337V16.667C1.6665 17.109 1.8421 17.5329 2.15466 17.8455C2.46722 18.1581 2.89114 18.3337 3.33317 18.3337H16.6665C17.1085 18.3337 17.5325 18.1581 17.845 17.8455C18.1576 17.5329 18.3332 17.109 18.3332 16.667V13.3337C18.3332 12.8916 18.1576 12.4677 17.845 12.1551C17.5325 11.8426 17.1085 11.667 16.6665 11.667H16.2498" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M5 5.00024H5.00833" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M5 15.0002H5.00833" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M13.0835 11.167L12.3335 10.917" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M7.6665 9.0835L6.9165 8.8335" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M8.8335 13.0835L9.0835 12.3335" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M11.3333 13.0836L11 12.2502" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M8.99984 7.75033L8.6665 6.91699" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M6.9165 11.3336L7.74984 11.0002" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M12.25 9.00033L13.0833 8.66699" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M11.1665 6.91699L10.9165 7.66699" stroke="hsl(var(--dark))" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_454_865">
      <rect width="20" height="20" fill="hsl(var(--white))" transform="translate(0 0.000244141)"/>
    </clipPath>
  </defs>
</svg>